create view schema_auto_increment_columns as
select `columns`.`TABLE_SCHEMA`                                                                    AS `TABLE_SCHEMA`,
       `columns`.`TABLE_NAME`                                                                      AS `TABLE_NAME`,
       `columns`.`COLUMN_NAME`                                                                     AS `COLUMN_NAME`,
       `columns`.`DATA_TYPE`                                                                       AS `DATA_TYPE`,
       `columns`.`COLUMN_TYPE`                                                                     AS `COLUMN_TYPE`,
       (locate('unsigned', `columns`.`COLUMN_TYPE`) = 0)                                           AS `is_signed`,
       (locate('unsigned', `columns`.`COLUMN_TYPE`) > 0)                                           AS `is_unsigned`,
       ((case `columns`.`DATA_TYPE`
           when 'tinyint' then 255
           when 'smallint' then 65535
           when 'mediumint' then 16777215
           when 'int' then 4294967295
           when 'bigint' then 18446744073709551615 end) >>
        if((locate('unsigned', `columns`.`COLUMN_TYPE`) > 0), 0, 1))                               AS `max_value`,
       `tables`.`AUTO_INCREMENT`                                                                   AS `AUTO_INCREMENT`,
       (`tables`.`AUTO_INCREMENT` / ((case `columns`.`DATA_TYPE`
                                        when 'tinyint' then 255
                                        when 'smallint' then 65535
                                        when 'mediumint' then 16777215
                                        when 'int' then 4294967295
                                        when 'bigint' then 18446744073709551615 end) >>
                                     if((locate('unsigned', `columns`.`COLUMN_TYPE`) > 0), 0, 1))) AS `auto_increment_ratio`
from (`information_schema`.`COLUMNS`
       join `information_schema`.`TABLES` on (((`columns`.`TABLE_SCHEMA` = `tables`.`TABLE_SCHEMA`) and
                                               (`columns`.`TABLE_NAME` = `tables`.`TABLE_NAME`))))
where ((`columns`.`TABLE_SCHEMA` not in ('mysql', 'sys', 'INFORMATION_SCHEMA', 'performance_schema')) and
       (`tables`.`TABLE_TYPE` = 'BASE TABLE') and (`columns`.`EXTRA` = 'auto_increment'))
order by (`tables`.`AUTO_INCREMENT` / ((case `columns`.`DATA_TYPE`
                                          when 'tinyint' then 255
                                          when 'smallint' then 65535
                                          when 'mediumint' then 16777215
                                          when 'int' then 4294967295
                                          when 'bigint' then 18446744073709551615 end) >>
                                       if((locate('unsigned', `columns`.`COLUMN_TYPE`) > 0), 0, 1))) desc,
         ((case `columns`.`DATA_TYPE`
             when 'tinyint' then 255
             when 'smallint' then 65535
             when 'mediumint' then 16777215
             when 'int' then 4294967295
             when 'bigint' then 18446744073709551615 end) >>
          if((locate('unsigned', `columns`.`COLUMN_TYPE`) > 0), 0, 1));

