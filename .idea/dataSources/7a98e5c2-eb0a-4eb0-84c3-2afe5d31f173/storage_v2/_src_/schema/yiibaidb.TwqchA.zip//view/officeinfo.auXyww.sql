create view officeinfo as
select `yiibaidb`.`offices`.`officeCode` AS `officeCode`,
       `yiibaidb`.`offices`.`phone`      AS `phone`,
       `yiibaidb`.`offices`.`city`       AS `city`
from `yiibaidb`.`offices`;

